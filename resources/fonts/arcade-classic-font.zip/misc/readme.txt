{
  set creator="koen hachmang";
  set licencetype="freeware";
  set website="http://www.koenhachmang.com";
  set e-mail="info@koenhachmang.com";
  set copyright="� past, present, future - Koen Hachmang";
}